Created A Stop Watch Web App using HTML, CSS and Java Script
